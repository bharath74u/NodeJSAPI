const axios = require("axios");
module.exports = {
  multipleGetAPIS: (urls, res) => {
    console.log("from servicejs======" + urls);

    let promiseArr = urls.map((url) =>
      axios.get(url).then((response) => {
        console.log(
          "axios get date and time is = ",
          url,
          new Date().toString()
        );
        return response.data;
      })
    );

    Promise.all(promiseArr)
      .then(function (values) {
        values.forEach((value) => {
          console.log("promiseAll date and time is = ", new Date().toString());
        });

        return res.send(values);
      })
      .catch(function (err) {
        console.log(err);
      });
  },
  multipleGetAPISChainExample: (urls, res) => {
    const service1 = axios
      .get("http://jsonplaceholder.typicode.com/users/1")
      .then((response) => {
        name1 = response.data.name;
        console.log("resp1 is==", name1);
        return axios.get("http://jsonplaceholder.typicode.com/users/2");

        //return res.send(name)
      })
      .then((resp2) => {
        name2 = resp2.data.name;
        console.log("resp2 is==", name2);
        return axios.get("http://jsonplaceholder.typicode.com/users/3");
      })
      .then((resp2) => {
        name3 = resp2.data.name;
        console.log("resp3 is==", name1, name2, name3);

       // return res.send(name1, name2, name3);
      })
      .catch((err) =>{
          console.log(err)
      })
      
  },

};
