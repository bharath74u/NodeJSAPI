#### Please use npm start ....to start the application
### two services are written. one to achive parallel processing. Other service is for chain process
#### chain service, we can implement in two ways. since it is sequential, either promise or sync/awit
##### in our project we use async/await for code to look better with respective understanding and number of lines
#### here i provided example with promise to show how much lines it added using promise.
### since our ask is parallel processing and async/await is sequential i didnt provide example


