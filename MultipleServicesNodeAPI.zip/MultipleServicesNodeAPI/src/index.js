const express = require('express')

require('dotenv').config(`${process.cwd()}/.env.local`)
const service=require('../service/service.js')

var app=express();
process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = 0;
const port=process.env.port||5000;
const urlsenv = process.env.urls
const urls=urlsenv.split(',')

app.get('/service',(req,res)=> {

    //Parallel Processing. i used 3 dummy JSON services. i used promiseAll.
    service.multipleGetAPIS(urls,res);
    //the below service is chain process (sequential). used same JSON services. if we have dependency from 1st service response
    // to call 2nd service. Here i used to fetch name from 1st service and i printed all names finally after all 3 services.
    //calls
    service.multipleGetAPISChainExample(urls,res);
    
    //here i have two responses to display in browser from the above two service calls.
    //for now i am displaying only one service response from multipleGetAPIS.
    //if we want to see chain process response then we need to comment line# 23 (return res.send(values);)
    //and uncomment // return res.send(name1, name2, name3); to view chain process response

        
console.log("End  is ===",   new Date().toString())



})

app.listen(port, (err)=> {

if(err){
    console.log("error=", err)
    throw new Error(err)
}

    console.log(`Node Server listening on port ${port}`)
})